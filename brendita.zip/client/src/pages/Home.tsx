import { useState } from "react";
import { ChevronLeft, ChevronRight, CircleHelp } from "lucide-react";

const coverMedia = [
  { type: "image", src: "https://imgur.com/mQuz6KJ.jpg" },
  { type: "video", src: "https://imgur.com/hy1zMpA.mp4" },
  { type: "video", src: "https://imgur.com/OCBznhV.mp4" },
] as const;

const avatarImage =
  "https://imgur.com/MmbkNFW.jpg";

const biography =
  "Putinha 18 aninho🔥 Aqui tem conteúdo todo dia, live e chat disponível pra gente conversar e se eu gostar de você, posso te dar um presentinho exclusivo 🤭😈";

const subscriptionLabel = "Assinar a partir de R$ 19,90";

function BrandMark() {
  return (
    <a className="brand" href="https://close.fans/?&" aria-label="Close Fans">
      <img className="brand-logo" src="/close-fans-logo.svg" alt="Close Fans" />
    </a>
  );
}

export default function Home() {
  const [activeImage, setActiveImage] = useState(0);
  const [expanded, setExpanded] = useState(false);

  const showPrevious = () =>
    setActiveImage((current) => (current - 1 + coverMedia.length) % coverMedia.length);
  const showNext = () =>
    setActiveImage((current) => (current + 1) % coverMedia.length);
  const activeMedia = coverMedia[activeImage];

  return (
    <div className="site-shell">
      <header className="site-header">
        <BrandMark />
      </header>

      <main className="profile-page">
        <section className="profile-cover" aria-label="Mídia do perfil">
          {activeMedia.type === "video" ? (
            <video
              key={activeMedia.src}
              className="cover-image"
              src={activeMedia.src}
              autoPlay
              muted
              loop
              playsInline
              preload="metadata"
              aria-label="Vídeo de capa"
            />
          ) : (
            <img
              key={activeMedia.src}
              className="cover-image"
              src={activeMedia.src}
              alt="close.fans/brenditaseja"
            />
          )}
          <div className="cover-shade" />

          <div className="cover-progress" aria-label={`Item ${activeImage + 1} de ${coverMedia.length}`}>
            {coverMedia.map((media, index) => (
              <button
                className={`progress-segment${index === activeImage ? " is-active" : ""}`}
                type="button"
                aria-label={media.type === "video" ? `Ver vídeo ${index + 1}` : `Ver foto ${index + 1}`}
                aria-current={index === activeImage ? "true" : undefined}
                key={media.src}
                onClick={() => setActiveImage(index)}
              />
            ))}
          </div>

          <button className="cover-arrow cover-arrow-left" type="button" onClick={showPrevious} aria-label="Foto anterior">
            <ChevronLeft size={23} strokeWidth={2} />
          </button>
          <button className="cover-arrow cover-arrow-right" type="button" onClick={showNext} aria-label="Próxima foto">
            <ChevronRight size={23} strokeWidth={2} />
          </button>
        </section>

        <section className="profile-info" aria-label="Perfil de Brenda Aguiar">
          <div className="profile-heading">
            <div className="identity">
              <img className="avatar" src={avatarImage} alt="Brenda Aguiar" />
              <div className="identity-copy">
                <h1>may moreira</h1>
                <p className="handle"><span aria-hidden="true">@</span> maymoreira</p>
              </div>
            </div>
            <button className="follow-button" type="button">Seguir Grátis</button>
          </div>

          <div className={`biography${expanded ? " is-expanded" : ""}`}>
            <p>{biography}</p>
            <button
              className="read-more"
              type="button"
              aria-expanded={expanded}
              onClick={() => setExpanded((value) => !value)}
            >
              {expanded ? "Mostrar menos" : "Mostrar mais"}
              <span className={`read-more-chevron${expanded ? " is-up" : ""}`} aria-hidden="true" />
            </button>
          </div>
        </section>

        <div className="subscribe-wrap">
          <a className="subscribe-button" href="https://checkout-pix.lovable.app/c/closefans">{subscriptionLabel}</a>
        </div>

        <div className="section-divider" />

        <section className="post-counts" aria-label="Publicações de Brenda Aguiar">
          <div className="count-item"><strong>377</strong><span>posts</span></div>
          <span className="count-divider" aria-hidden="true" />
          <div className="count-item"><strong>160</strong><span>fotos</span></div>
          <span className="count-divider" aria-hidden="true" />
          <div className="count-item"><strong>199</strong><span>vídeos</span></div>
        </section>

        <section className="locked-post" aria-label="Conteúdo para assinantes">
          <div className="locked-watermark" aria-hidden="true">
            <img className="watermark-logo" src="/close-fans-symbol.svg" alt="" />
          </div>
          <div className="locked-action">
            <button className="subscribe-button" type="button">{subscriptionLabel}</button>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-main">
          <a className="help-link" href="#">
            <CircleHelp size={21} strokeWidth={1.7} aria-hidden="true" />
            <span>Preciso de ajuda</span>
          </a>
          <div className="social-links" aria-label="Redes sociais Close Fans">
            <a href="https://t.me/Close_Fans_Oficial" aria-label="Telegram Close Fans">
              <img src="https://close.fans/images/ico-telegram-dark-grey.svg" alt="" />
            </a>
            <a href="https://www.instagram.com/closefans.oficial" aria-label="Instagram Close Fans">
              <img src="https://close.fans/images/ico-instagram-dark-grey.svg" alt="" />
            </a>
          </div>
        </div>
        <nav className="legal-links" aria-label="Links legais">
          <a href="https://close.fans/termos-politica-de-privacidade?&">Privacidade</a>
          <span aria-hidden="true">|</span>
          <a href="https://close.fans/termos-de-uso?&">Termos de Serviço</a>
        </nav>
      </footer>
    </div>
  );
}
