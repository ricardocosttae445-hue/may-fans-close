# TODO

## Cabeçalho, perfil e controles de assinatura
- [x] Exibir o perfil responsivo com o avatar selecionado `https://imgur.com/MmbkNFW.jpg`, o nome “may moreira” e o identificador “@ maymoreira”, preservando a hierarquia visual, cores, tipografia, espaçamentos e dimensões da referência.
- [x] Reproduzir visualmente o controle “Seguir Grátis”, sem adicionar autenticação ou fluxo que não exista no material.
- [x] Reproduzir visualmente a chamada “Assinar a partir de R$ 19,90”, sem implementar checkout ou processamento de pagamento dentro deste site.
- [x] Aplicar o destino `https://checkout-pix.lovable.app/c/closefans` somente ao botão principal “Assinar a partir de R$ 19,90” selecionado no Preview; manter sem alterações o CTA duplicado sobre o conteúdo bloqueado.

- [x] Preservar integralmente a biografia: “Putinha 18 aninho🔥 Aqui tem conteúdo todo dia, live e chat disponível pra gente conversar e se eu gostar de você, posso te dar um presentinho exclusivo 🤭😈”.
- [x] Exibir “Mostrar mais” com apresentação e comportamento visual compatíveis com a referência.
- [x] No carrossel, manter o primeiro item como a imagem `https://imgur.com/mQuz6KJ.jpg`, manter o segundo item como vídeo inline `https://imgur.com/hy1zMpA.mp4` e converter o terceiro item em vídeo inline `https://imgur.com/OCBznhV.mp4`, ambos com reprodução automática, mudo, em loop e sem controles.
- [x] Exibir os indicadores “377 posts”, “160 fotos” e “199 vídeos”.

## Links, rodapé e fidelidade ao material
- [x] Preservar os links sociais observados no HTML: Telegram para `https://t.me/Close_Fans_Oficial` e Instagram para `https://www.instagram.com/closefans.oficial`.
- [x] Exibir no rodapé “Preciso de ajuda”, “Privacidade” e “Termos de Serviço”, mantendo os destinos encontrados no HTML de referência.
- [x] Preservar os textos, imagens e elementos de interface não alterados pelas edições confirmadas do Preview.
- [x] Excluir do HTML copiado scripts de rastreamento e extensões de navegador; manter somente a interface e as ações visuais observadas, sem funcionalidades adicionais.
