export default { logoUrl: "https://static.close.fans/account/172976194821/111949.avatar.jpg" };
